#ifndef LAB_03_LINKED_LIST_LINKEDLIST_H
#define LAB_03_LINKED_LIST_LINKEDLIST_H
#include "LinkedListInterface.h"
//took me so long to figure out how to inherit a template
//and declare one. Still not sure what I'm doing.
template <typename T>
class LinkedList : public LinkedListInterface<T> {
public:
    LinkedList() {
        head = nullptr; //Initializing both head and tail to null
        tail = nullptr;
    }

    ~LinkedList() = default;

    /** Insert Node(value) at beginning of linked list */
    virtual void push_front(const T& value) {
        Node* node = new Node(value, head, nullptr);
        if (node->GetNext() == nullptr) {
            tail = node;
        }
        else {
            node->GetNext()->SetPrevious(node); //ha. I didn't even know you could do a double arrow like this
        }                                       //until I did it by accident.
        head = node;
    }

    /** Remove Node at beginning of linked list */
    //This one is pretty self-explanatory
    virtual void pop_front(void) {
        if (head != nullptr) {
            if (head->GetNext() == nullptr) {       //SO ANNOYING. I didn't realize you have to set a pointer to null after
                delete head;                        //deleting it. Figured it out halfway through the lab and had to spend
                tail = nullptr;                     //forever playing catch up on all my functions
                head = nullptr;
            }
            else {
                Node* tempVal = head;
                head = head->GetNext();
                delete tempVal;
                head->SetPrevious(nullptr);
            }
        }
    }

    /** Return reference to value of Node at beginning of linked list */
    //I waited in the TA line for an hour and a half just to have him
    //tell me to access the data directly (i.e. head->data;
    //instead of head->GetData();) I was about ready to throw my laptop.
    //Catch that you stupid try block.
    virtual T& front(void) {
        return head->data;
    }

    /** Return true if linked list size == 0 */
    //Easy enough
    virtual bool empty(void) const {
        if (head == nullptr) {
            return true;
        }
        else {
            return false;
        }
    }

    /** Remove all Nodes with value from linked list */
    //Hate hate hate hate hate hate hate hate hate hate
    //hate hate hate hate hate hate hate hate hate hate
    virtual void remove(const T& value) {
        Node* currentNode = head;
        while (currentNode != nullptr) { //run through the nodes till the end
            if (currentNode->GetData() == value) { //if the node has the data
                if (currentNode == head) {
                    currentNode = currentNode->GetNext(); //set currentNode to next. Will set to nullptr if end of list
                    pop_front(); //pop is such fabulous way of describing what I want to do to these nodes
                }
                else if (currentNode == tail) {
                    pop_back();
                    currentNode = nullptr; //already at the end of the list, so just make it null
                }
                else { //if in the middle of the list, do this messy shenanigan
                    Node* tempVal = currentNode;
                    Node* prevNode = currentNode->GetPrevious();
                    currentNode = currentNode->GetNext();
                    prevNode->SetNext(currentNode);
                    currentNode->SetPrevious(prevNode);
                    delete tempVal;
                }
            }
            else {
                currentNode = currentNode->GetNext(); //don't forget to update your list folks or your computer
            }                                         //will never finish running your program
        }                                             //which I obviously did not do
    }                                                 //because I never make mistakes coding
                                                      //Ever
    /** Remove all Nodes from linked list */
    //Also self-explanatory
    virtual void clear(void) {
        while (head != nullptr) {
            pop_front();
        }
        head = nullptr; //got so many valgrind errors till I added this smh
        tail = nullptr;
    }

    /** Reverse Nodes in linked list */
    //surprisingly did not have the most trouble with this one.
    //I think it's easier if you did the extra credit stuff
    virtual void reverse(void) {
        Node* currentNode = head;
        Node* tempNode;
        while (currentNode != nullptr) {
            tempNode = currentNode;
            currentNode = currentNode->GetNext();
            tempNode->SetNext(tempNode->GetPrevious());
            tempNode->SetPrevious(currentNode);
        }
        tail = head; //totally forgot this part though when I first did it
        head = tempNode;
    }

    /** Return the number of nodes in the linked list */
    //Easy stuff
    virtual size_t size(void) const {
        Node* currentNode = head;
        size_t numNodes = 0;
        while (currentNode != nullptr) {
            numNodes++;
            currentNode = currentNode->GetNext();
        }
        return numNodes;
    }

    /** Return contents of Linked List as a string */
    //Frustrating stuff. This friend insertion + toString is so annoying sometimes
    virtual std::string toString(void) const {
        std::string content;
        Node* currentNode = head;
        while (currentNode != nullptr) {
            content += currentNode->GetData() + " ";
            currentNode = currentNode->GetNext();
        }
        return content;
    }

    /** BONUS ** Insert Node(value) at end of linked list */
    //Pretty much just copied and inverted my push_front function.
    //Once I figured it out, of course
    //Which took a very
    //very
    //long time
    virtual void push_back(const T& value) {
        Node* node = new Node(value, nullptr, tail);
        if (node->GetPrevious() == nullptr) {
            head = node;
        }
        else {
            node->GetPrevious()->SetNext(node);
        }
        tail = node;
    }


    /** BONUS ** Remove Node at end of linked list */
    //Same here
    virtual void pop_back(void) {
        if (tail != nullptr) {
            if (tail->GetPrevious() == nullptr) {
                delete tail;
                tail = nullptr;
                head = nullptr;
            }
            else {
                Node* tempVal = tail;
                tail = tail->GetPrevious();
                delete tempVal;
                tail->SetNext(nullptr);
            }
        }
    }

    /** BONUS ** Return reference to value of Node at end of linked list */
    //see front()
    virtual T& back(void) {
        return tail->data;
    }

    //HA funny story so I read the lab requirements quickly and thought
    //that I couldn't #include ANYTHING so I was struggling hardcore
    //to find a different way of just using string instead of ostream
    //It was painful.
    friend std::ostream& operator<< (std::ostream& os, const LinkedList& list) {
        os << list.toString();
        return os;
    }

private:
    struct Node { //this class declared in a class stuff is mind-blowing
        Node(T data, Node* next, Node* previous) {
            this->data = data;
            this->next = next;
            this->previous = previous;
        }
        ~Node() = default;
        Node* GetNext() const { return next; }
        Node* GetPrevious() const { return previous; }
        T GetData() const { return data; }
        void SetNext(Node* next) { this->next = next; }
        void SetPrevious(Node* previous) { this->previous = previous; }
        T data;
        Node* next;
        Node* previous;
    };
    Node* head;
    Node* tail;
};



#endif //LAB_03_LINKED_LIST_LINKEDLIST_H
