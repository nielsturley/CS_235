#include <iostream>
#include <fstream>
#include <sstream>
#include "Maze.h"


int main(int argc, char* argv[]) {
	std::ifstream in(argv[1]);
	std::ofstream out(argv[2]);

	int height;
	int width;
	int layers;
	in >> height >> width >> layers;
	Maze myMaze = Maze(height, width, layers);
	std::string line;
	in.ignore();
	in.ignore();
	for (int i = 0; i < layers; ++i) {
		for (int j = 0; j < height; ++j) {
			getline(in, line);
			std::istringstream iss(line);
			for (int k = 0; k < width; ++k) {
				int value;
				iss >> value;
				myMaze.setValue(j, k, i, value);
			}
		}
		in.ignore();
	}

	out << "Solve Maze:" << std::endl;
	out << myMaze.toString();
	if (!myMaze.find_maze_path()) {
		out << "No Solution Exists!" << std::endl;
	}
	else {
		out << "Solution:" << std::endl;
		out << myMaze.toString();
	}

	in.close();
	out.close();

	return 0;
}
