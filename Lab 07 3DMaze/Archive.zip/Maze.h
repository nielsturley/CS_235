#ifndef LAB_07_3DMAZE_MAZE_H
#define LAB_07_3DMAZE_MAZE_H

#include "MazeInterface.h"

enum CellValue_t { OPEN, BLOCKED, VISITED, EXIT, LEFT, RIGHT, UP, DOWN, OUT, IN };
#define CHECK_LEFT h,w-1,l
#define CHECK_RIGHT h,w+1,l
#define CHECK_UP h-1,w,l
#define CHECK_DOWN h+1,w,l
#define CHECK_OUT h,w,l-1
#define CHECK_IN h,w,l+1

class Maze : public MazeInterface {
private:
	int*** maze;
	int height;
	int width;
	int layer;
public:
	Maze(int height, int width, int layer) {
		this->height = height;
		this->width = width;
		this->layer = layer;
		makeMaze();
	}

	void makeMaze() {
		maze = new int**[height];
		for (int i = 0; i < height; ++i) {
			maze[i] = new int*[width];
			for (int j = 0; j < width; ++j) {
				maze[i][j] = new int[layer];
			}
		}
	}

	~Maze() {
		for (int i = 0; i < height; ++i) {
			for (int j = 0; j < width; ++j) {
				delete [] maze[i][j];
			}
			delete [] maze[i];
		}
		delete [] maze;
	}

	void setValue(int height, int width, int layer, int value) {
		if (value == 0) {
			maze[height][width][layer] = OPEN;
		}
		if (value == 1) {
			maze[height][width][layer] = BLOCKED;
		}
	}

	bool find_maze_path() {
		maze[height-1][width-1][layer-1] = EXIT;
		return rec_find_maze_path(0, 0, 0);
	}

	bool rec_find_maze_path(int h, int w, int l) {
		if (out_of_bounds_check(h, w, l) || maze[h][w][l] == BLOCKED || maze[h][w][l] == VISITED) return false;
		if (maze[h][w][l] == EXIT) return true;
		maze[h][w][l] = VISITED;
		if (rec_find_maze_path(CHECK_LEFT)) {
			maze[h][w][l] = LEFT;
			return true;
		}
		if (rec_find_maze_path(CHECK_RIGHT)) {
			maze[h][w][l] = RIGHT;
			return true;
		}
		if (rec_find_maze_path(CHECK_UP)) {
			maze[h][w][l] = UP;
			return true;
		}
		if (rec_find_maze_path(CHECK_DOWN)) {
			maze[h][w][l] = DOWN;
			return true;
		}
		if (rec_find_maze_path(CHECK_OUT)) {
			maze[h][w][l] = OUT;
			return true;
		}
		if (rec_find_maze_path(CHECK_IN)) {
			maze[h][w][l] = IN;
			return true;
		}
		return false;
	}

	bool out_of_bounds_check(int h, int w, int l) {
		if (h < 0 || w < 0 || l < 0 || h >= height || w >= width || l >= layer) {
			return true;
		}
		else {
			return false;
		}
	}

	std::string toString() const {
		std::stringstream out;
		for (int i = 0; i < layer; ++i) {
			out << "Layer " << std::to_string(i + 1) << std::endl;
			for (int j = 0; j < height; ++j) {
				for (int k = 0; k < width; ++k) {
					out << " " << interpretValue(maze[j][k][i]);
				}
				out << std::endl;
			}
		}
		out << std::endl;
		return out.str();
	}

	char interpretValue(int value) const {
		switch(value) {
			case 0:
				return '_';
			case 1:
				return 'X';
			case 2:
				return '*';
			case 3:
				return 'E';
			case 4:
				return 'L';
			case 5:
				return 'R';
			case 6:
				return 'U';
			case 7:
				return 'D';
			case 8:
				return 'O';
			case 9:
				return 'I';
			default:
				throw std::string("Error");
		}
	}



};

#endif //LAB_07_3DMAZE_MAZE_H
