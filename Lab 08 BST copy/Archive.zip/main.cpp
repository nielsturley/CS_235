#include <iostream>
#include <sstream>
#include <fstream>

#include "BST.h"


int main(int argc, char* argv[]) {
	std::ifstream in(argv[1]);
	std::ofstream out(argv[2]);


	BST<int> intBST;
	BST<std::string> stringBST;

	for (std::string line; getline(in, line);) {
		std::string command, itemToImport;
		if (line.empty()) { continue; }
		std::istringstream iss(line);
		iss >> command;
		out << command;


		if (command == "INT") {
			intBST.clearTree();
			stringBST.clearTree();
			out << " true";
		}
		if (command == "STRING") {
			intBST.clearTree();
			stringBST.clearTree();
			out << " true";
		}

		if (command == "add") {
			iss >> itemToImport;
			out << " " << itemToImport;
			if (isdigit(itemToImport.at(0))) { //If the input is a digit
				if (intBST.addNode(stoi(itemToImport))) { out << " true"; } //add it to the int tree
				else { out << " false"; }
			}
			else { //else
				if (stringBST.addNode(itemToImport)) { out << " true"; } //add it to the string tree
				else { out << " false"; }
			}
		}

		if (command == "remove") {
			iss >> itemToImport;
			out << " " << itemToImport;
			if (isdigit(itemToImport.at(0))) {
				if (intBST.removeNode(stoi(itemToImport))) { out << " true"; }
				else { out << " false"; }
			}
			else {
				if (stringBST.removeNode(itemToImport)) { out << " true"; }
				else { out << " false"; }
			}
		}

		if (command == "clear") {
			intBST.clearTree();
			stringBST.clearTree();
			out << " true";
		}

		if (command == "size") {
			int size = intBST.size();
			if (size != 0) {
				out << " " << size;
			}
			else {
				out << " " << stringBST.size();
			}
		}

		if (command == "print") {
			out << ":";
			if (intBST.size() != 0) { out << intBST; }
			else if (stringBST.size() != 0) { out << stringBST; }
			else { out << " empty"; }
		}

		if (command == "find") {
			iss >> itemToImport;
			out << " " << itemToImport;
			if (isdigit(itemToImport.at(0))) {
				if (intBST.search(stoi(itemToImport))) { out << " found"; }
				else { out << " not found"; }
			}
			else {
				if (stringBST.search(itemToImport)) { out << " found"; }
				else { out << " not found"; }
			}
		}

		if (command == "tree") {
			out << ":";
			if (intBST.size() != 0) {
				BST<int>::Iterator iter = intBST.begin();
				BST<int>::Iterator endIter = intBST.end();
				while (iter != endIter) {
					out << " " << *iter;
					++iter;
				}
			}
			else if (stringBST.size() != 0) {
				BST<std::string>::Iterator iter = stringBST.begin();
				BST<std::string>::Iterator endIter = stringBST.end();
				while (iter != endIter) {
					out << " " << *iter;
					++iter;
				}
			}
			else { out << " empty"; }
		}
		out << std::endl;
	}

	in.close();
	out.close();

	return 0;
}
