#ifndef LAB_05_EXPRESSIONS_EXPRESSIONMANAGER_H
#define LAB_05_EXPRESSIONS_EXPRESSIONMANAGER_H
#include "ExpressionManagerInterface.h"
#include <stack>
#include <vector>
#include <sstream>
#include <algorithm>

class ExpressionManager : public ExpressionManagerInterface {
public:
    ExpressionManager() = default;

    ~ExpressionManager() = default;

    void setExpression(std::string const& exp) {
        expression_ = exp;
        inFix_.clear();
        preFix_.clear();
        postFix_.clear();
    }

    /** Return the integer value of the infix expression */
    virtual int value(void) {
        if (postFix_.empty()) {
            postfix();
        }
        std::stack<int> stack;
        for (int i = 0; i < postFix_.size(); ++i) {
            if (isOperand(postFix_.at(i))) {
                stack.push(stoi(postFix_.at(i)));
            }
            if (isOperator(postFix_.at(i))) {
                //Error check for <2 elements?
                int right = stack.top();
                stack.pop();
                int left = stack.top();
                stack.pop();
                if (postFix_.at(i) == "-") {
                    stack.push(left - right);
                }
                if (postFix_.at(i) == "+") {
                    stack.push(left + right);
                }
                if (postFix_.at(i) == "*") {
                    stack.push(left * right);
                }
                if (postFix_.at(i) == "/") {
                    stack.push(left / right);
                }
                if (postFix_.at(i) == "%") {
                    stack.push(left % right);
                }
            }
        }
        return stack.top();
    }

    /** Return the infix items from the expression
        Throw an error if not a valid infix expression as follows:
        First check to see if the expression is balanced ("Unbalanced"),
        then throw the appropriate error immediately when an error is found
        (ie., "Missing Operand", "Illegal Operator", "Missing Operator") */
    virtual std::string infix(void) {
        std::stack<std::string> stack;
        std::istringstream iss(expression_);
        std::string next;
        while (iss >> next) {
            if (isLeftParen(next)) {
                stack.push(next);
            }
            if (isRightParen(next)) {
                if (isPair(stack.top(), next)) {
                    stack.pop();
                }
                else {
                    throw std::string(" Unbalanced");
                }
            }
        }
        if (!stack.empty()) {
            throw std::string(" Unbalanced");
        }
        iss.str(expression_);
        iss.clear();
        while (iss >> next) {
            if (stack.empty()) {
                if (isOperand(next) || isLeftParen(next)) {
                    inFix_.push_back(next);
                    stack.push(next);
                }
                else {
                    throw std::string(" Missing Operand");
                }
            }
            else {
                if (isOperator(next)) {
                    if (isOperand(stack.top()) || isRightParen(stack.top())) {
                        inFix_.push_back(next);
                        stack.push(next);
                    }
                    else {
                        throw std::string(" Missing Operand");
                    }
                }
                else if (isOperand(next)) {
                    if (isOperator(stack.top()) || isLeftParen(stack.top())) {
                        inFix_.push_back(next);
                        stack.push(next);
                    }
                    else {
                        throw std::string(" Missing Operator");
                    }
                }
                else if (isLeftParen(next)) {
                    if (isOperator(stack.top()) || isLeftParen(stack.top())) {
                        inFix_.push_back(next);
                        stack.push(next);
                    }
                    else {
                        throw std::string(" Missing Operator");
                    }
                }
                else if (isRightParen(next)) {
                    if (isOperand(stack.top()) || isRightParen(stack.top())) {
                        inFix_.push_back(next);
                        stack.push(next);
                    }
                    else {
                        throw std::string(" Missing Operand");
                    }
                }
                else {
                    throw std::string(" Illegal Operator");
                }
            }
        }
        if (isOperator(stack.top()) || isLeftParen(stack.top())) {
            throw std::string(" Missing Operand");
        }
        return toString();
    }

    /** Return a postfix representation of the infix expression */
    virtual std::string postfix(void) {
        if (inFix_.empty()) {
            infix();
        }
        std::stack<std::string> stack;
        for (int i = 0; i < inFix_.size(); ++i) {
            if (isOperand(inFix_.at(i))) {
                postFix_.push_back(inFix_.at(i));
            }
            else {
                processOperatorPostfix(inFix_.at(i), stack, postFix_);
            }
        }
        while (!stack.empty()) {
            postFix_.push_back(stack.top());
            stack.pop();
        }
        std::string out;
        for (int i = 0; i < postFix_.size(); ++i) {
            out += " " + postFix_.at(i);
        }
        return out;
    }

    void processOperatorPostfix(std::string const& operator_, std::stack<std::string>& stack, std::vector<std::string>& postFix_) {
        if (stack.empty() || isLeftParen(operator_)) {
            stack.push(operator_);
        }
        else {
            if (precedence(operator_) > precedence(stack.top())) {
                stack.push(operator_);
            }
            else {
                while (!stack.empty() && !isLeftParen(stack.top()) && (precedence(operator_) <= precedence(stack.top()))) {
                    postFix_.push_back(stack.top());
                    stack.pop();
                }
                if (isRightParen(operator_)) {
                    stack.pop();
                }
                else {
                    stack.push(operator_);
                }
            }
        }
    }

    /** Return a prefix representation of the infix expression */
    virtual std::string prefix(void) {
        if (inFix_.empty()) {
            infix();
        }
        std::vector<std::string> tempPreFix_ = inFix_;
        std::reverse(tempPreFix_.begin(), tempPreFix_.end());
        for (int i = 0; i < tempPreFix_.size(); ++i) {
            if (isLeftParen(tempPreFix_.at(i))) {
                if (tempPreFix_.at(i) == "(") {
                    tempPreFix_.at(i) = ")";
                }
                if (tempPreFix_.at(i) == "[") {
                    tempPreFix_.at(i) = "]";
                }
                if (tempPreFix_.at(i) == "{") {
                    tempPreFix_.at(i) = "}";
                }
            }
            else if (isRightParen(tempPreFix_.at(i))) {
                if (tempPreFix_.at(i) == ")") {
                    tempPreFix_.at(i) = "(";
                }
                if (tempPreFix_.at(i) == "]") {
                    tempPreFix_.at(i) = "[";
                }
                if (tempPreFix_.at(i) == "}") {
                    tempPreFix_.at(i) = "{";
                }
            }
        }
        std::stack<std::string> stack;
        for (int i = 0; i < tempPreFix_.size(); ++i) {
            if (isOperand(tempPreFix_.at(i))) {
                preFix_.push_back(tempPreFix_.at(i));
            }
            else {
                processOperatorPrefix(tempPreFix_.at(i), stack, preFix_);
            }
        }
        while (!stack.empty()) {
            preFix_.push_back(stack.top());
            stack.pop();
        }
        std::reverse(preFix_.begin(), preFix_.end());
        std::string out;
        for (int i = 0; i < preFix_.size(); ++i) {
            out += " " + preFix_.at(i);
        }
        return out;
    }

    void processOperatorPrefix(std::string const& operator_, std::stack<std::string>& stack, std::vector<std::string>& preFix_) {
        if (stack.empty() || isLeftParen(operator_)) {
            stack.push(operator_);
        }
        else {
            if (precedence(operator_) >= precedence(stack.top())) {
                if (isLeftParen(stack.top()) && isRightParen(operator_)) {
                    stack.pop();
                }
                else {
                    stack.push(operator_);
                }
            }
            else {
                while (!stack.empty() && !isLeftParen(stack.top()) && (precedence(operator_) < precedence(stack.top()))) {
                    preFix_.push_back(stack.top());
                    stack.pop();
                }
                if (isRightParen(operator_)) {
                    stack.pop();
                }
                else {
                    stack.push(operator_);
                }
            }
        }
    }

    /** Return the infix vector'd expression items */
    virtual std::string toString(void) const {
        std::string out;
        for (int i = 0; i < inFix_.size(); ++i) {
            out += " " + inFix_.at(i);
        }
        return out;
    }

    friend std::ostream& operator<< (std::ostream& os, const ExpressionManager& exp) {
        os << exp.toString();
        return os;
    }

    bool isLeftParen(const std::string& t) const {
        if (t == "(" || t == "[" || t == "{") {
            return true;
        }
        else {
            return false;
        }
    }

    bool isRightParen(const std::string& t) const {
        if (t == ")" || t == "]" || t == "}") {
            return true;
        }
        else {
            return false;
        }
    }

    bool isPair(std::string const& left, std::string const& right) const {
        if (left == "(" && right == ")") {
            return true;
        }
        if (left == "[" && right == "]") {
            return true;
        }
        if (left == "{" && right == "}") {
            return true;
        }
        return false;
    }

    bool isOperator(std::string t) {
        if (OPERATORS.find(t) != std::string::npos) {
            return true;
        }
        else {
            return false;
        }
    }

    bool isOperand(std::string t) {
        for (int i = 0; i < t.size(); ++i) {
            if (!isdigit(t.at(i))) {
                return false;
            }
        }
        return true;
    }

    int precedence(std::string const& operator_) const {
        if (operator_ == "*" || operator_ == "/" || operator_ == "%") {
            return 2;
        }
        if (operator_ == "+" || operator_ == "-") {
            return 1;
        }
        if (isLeftParen(operator_) || isRightParen(operator_)) {
            return 0;
        }
        throw std::string(" Illegal Operator");
    }

private:
    std::string expression_;
    std::vector<std::string> inFix_;
    std::vector<std::string> postFix_;
    std::vector<std::string> preFix_;
    const std::string OPERATORS = "-+*/%";

};

#endif //LAB_05_EXPRESSIONS_EXPRESSIONMANAGER_H
