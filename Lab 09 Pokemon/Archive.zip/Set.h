#ifndef LAB_09_POKEMON_SET_H
#define LAB_09_POKEMON_SET_H

#include "SetInterface.h"
#include "LinkedList.h"

template<typename T>
class Set : public SetInterface<T> {
private:
	LinkedList<std::string> set;
public:
	Set() = default;
	~Set() = default;

	bool insert(const T& item) {
		if (set.find(set.begin(), set.end(), item)) {
			return false;
		}
		LinkedList<std::string>::Iterator iter;
		LinkedList<std::string>::Iterator iterEnd;
		iter = set.begin();
		iterEnd = set.end();
		if (set.empty()) {
			set.push_back(item);
		}
		else {
			while (iter != iterEnd) {
				if (*iter > item) {
					set.insert(iter, item);
					return true;
				}
				++iter;
			}
			set.push_back(item);
			return true;
		}
		return false;
	}

	void clear() {
		set.clear();
	}

	size_t size() const {
		return set.size();
	}

	size_t count(const T& item) {
		LinkedList<std::string>::Iterator iter;
		LinkedList<std::string>::Iterator iterEnd;
		iter = set.begin();
		iterEnd = set.end();
		if (set.empty()) { return 0; }
		if (set.find(iter, iterEnd, item)) { return 1; }
		else { return 0; }
	}

	std::string toString() const {
		std::stringstream out;
		out << set;
		return out.str();
	}

	friend std::ostream& operator<< (std::ostream& os, const Set& set_) {
		os << set_.toString();
		return os;
	}
};
#endif //LAB_09_POKEMON_SET_H
