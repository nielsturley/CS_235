#ifndef LAB_09_POKEMON_HASHMAP_H
#define LAB_09_POKEMON_HASHMAP_H

#include "HashMapInterface.h"
#include "Pair.h"
#include "Set.h"
#include <cmath>

template<typename K, typename V>
class HashMap : public HashMapInterface<K,V> {
private:
	size_t capacity;
	size_t numPairs;
	Pair<K, V>* pairs;
public:
	HashMap() :
		capacity(DEFAULT_MAP_HASH_TABLE_SIZE),
		numPairs(0),
		pairs(new Pair<K,V>[DEFAULT_MAP_HASH_TABLE_SIZE]) {}

	~HashMap() { delete[] pairs; }

	/** Read/write index access operator.
	If the key is not found, an entry is made for it.
	@return: Read and write access to the value mapped to the provided key. */
	V& operator[](const K& key) {
		long long hashIndex = calculateHash(key);
		int k = -1;
		double num = numPairs;
		double cap = capacity;
		double load = (num / cap) * 100;
		if (load > LOAD_THRESHOLD) {
			reallocate();
		}
		while (true) {
			if (pairs[hashIndex].first.length() == 0) {
				pairs[hashIndex].first = key;
				++numPairs;
				break;
			}
			if (pairs[hashIndex].first == key) {
				break;
			}
			k += 2;
			hashIndex = (hashIndex + k) % capacity;
		}
		return pairs[hashIndex].second;
	}

	/** @return: the number of elements that match the key in the Map. */
	size_t count(const K& key) {
		long long hashIndex = calculateHash(key);
		if (pairs[hashIndex].first == key) { return 1; }
		else { return 0; }
	}

	/** Removes all items from the Map. */
	void clear();

	/** @return: number of Key-Value pairs stored in the Map. */
	size_t size() const {
		return numPairs;
	}

	/** @return: maximum number of Key-Value pairs that the Map can hold. */
	size_t max_size() const {
		return capacity;
	}

	/** @return: string representation of Key-Value pairs in Map. */
	std::string toString() const {
		std::stringstream out;
		for (size_t i = 0; i < capacity; ++i) {
			if (pairs[i].first.length() != 0) {
				out << "  [" << i << ":" << pairs[i].first << "->" << pairs[i].second << "]\n";
			}
		}
		return out.str();
	}

	friend std::ostream& operator<< (std::ostream& os, const HashMap& hashMap) {
		os << hashMap.toString();
		return os;
	}

	long long calculateHash(const K& key) const {
		long long hash = 0;
		for (unsigned int i = 0; i < key.size(); ++i) {
			hash += (key[i] * pow(HASH_CONSTANT, (key.size() - 1 - i)));
		}
		hash = hash % capacity;
		//std::cout << "Hash calculated: " << hash << std::endl;
		return hash;
	}

	void reallocate() {
		size_t oldCapacity = capacity;
		capacity *= 2;
		Pair<K,V>* newData = new Pair<K,V>[capacity];
		for (size_t i = 0; i <= oldCapacity; ++i) {
			if (pairs[i].first.length() == 0) { continue; }
			int k = -1;
			long long hashIndex = calculateHash(pairs[i].first);
			while (true) {
				if (newData[hashIndex].first.length() == 0) {
					newData[hashIndex].first = pairs[i].first;
					newData[hashIndex].second = pairs[i].second;
					break;
				}
				k += 2;
				hashIndex = (hashIndex + k) % capacity;
			}
		}
		std::swap(pairs, newData);
		delete[] newData;
	}

};

template<>
void HashMap<std::string, Set<std::string> >::clear() {
	for (size_t i = 0; i < capacity; ++i) {
		if (pairs[i].first.length() != 0) {
			pairs[i].first = "";
			pairs[i].second.clear();
		}
	}
	numPairs = 0;
}

template<>
void HashMap<std::string, std::string>::clear() {
	for (size_t i = 0; i < capacity; ++i) {
		if (pairs[i].first.length() != 0) {
			pairs[i].first = "";
			pairs[i].second = "";
		}
	}
	numPairs = 0;
}
#endif //LAB_09_POKEMON_HASHMAP_H
